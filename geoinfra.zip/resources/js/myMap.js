

import 'ol/ol.css';
import {Map, View} from 'ol';
import Control from 'ol/control/Control';
import TileLayer from 'ol/layer/Tile';

import TileWMS from 'ol/source/TileWMS';
import OSM from 'ol/source/OSM';
import $ from "jquery";
import {ZoomSlider} from 'ol/control';
//import {Sidebar} from 'ol/control.js';
//import {LayerSwitcher} from 'ol/ol-layerswitcher/dist/ol-layerswitcher';
//import { html, LitElement } from './lit-element/lit-element.js';


var my_map = {                       // <-- add this line to declare the object
    display: function () {           // <-- add this line to declare a method 

////////////////SOURCES///////////////////////////////

const sourceParcelas = new TileWMS(({
    url: "http://geo.arba.gov.ar/geoserver/idera/wms",
    attributions: ' ',
    params: {
        "LAYERS": "Parcela",
        "TILED": "true",
        "VERSION": "1.3.0"},
    
}));
const sourceZUsos = new ol.source.TileWMS(({
    url: "http://www.urbasig.gob.gba.gob.ar/geoserver/urbasig/wms",
      attributions: ' ',
    params: {
      "LAYERS": "zonificacion_zonas_espe",
      "TILED": "true",
      "VERSION": "1.3.0"},
  }));

  const sourceMunicipalidades = new ol.source.TileWMS(({
    url: "http://www.urbasig.gob.gba.gob.ar/geoserver/urbasig/wms",
      attributions: ' ',
    params: {
      "LAYERS": "municipalidades",
      "TILED": "true",
      "VERSION": "1.3.0"},
  }));
const sourceDepartamentos = new ol.source.TileWMS(({

    url: "http://geo.arba.gov.ar/geoserver/idera/wms",
      attributions: ' ',
    params: {
      "LAYERS": "Departamento",
      "TILED": "true",
      "VERSION": "1.3.0"},
  }));
const sourceHidro = new ol.source.TileWMS(({
    url: "http://www.mosp.gba.gov.ar/sig_hidraulica/ms/publico/wms.xml",
      attributions: ' ',
    params: {
      "LAYERS": "HidrografiaBuenosAires",
      "TILED": "true",
      "VERSION": "1.3.0"},
  }));

////////declaracion de capas//////////////////////////////

        const googleSat = new ol.layer.Tile({
            'title': 'Google Satelite',
            'type': 'base',
            'opacity': 1.000000,
            source: new ol.source.XYZ({
                attributions: ' ',
                        url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });

        const OSM = new ol.layer.Tile({
            // A layer must have a title to appear in the layerswitcher
            title: 'OSM',
            // Again set this layer as a base layer
            type: 'base',
            visible: true,
            source: new ol.source.OSM()
        });

        const parcelas =  new ol.layer.Tile({
            source: sourceParcelas,
            title: "Parcelas",
            visible: false,
            opacity: 1.000000,                                 
            
        });

        const zUsos = new ol.layer.Tile({
            source: sourceZUsos,
            title: "Zonificación segun Usos",
            opacity: 1.000000,
            visible: false,
            
          });

          const municipalidades =  new ol.layer.Tile({
            source: sourceMunicipalidades,
            title: "Municipalidades",
            opacity: 1.000000,
            visible: false,
            
          });

          const departamentos = new ol.layer.Tile({
            source: sourceDepartamentos,
            title: "Departamentos",
            opacity: 1.000000,
            visible: false,
            crossOrigin: 'no-cors'
          });

          const hidrografia =  new ol.layer.Tile({
            source: sourceHidro,
            title: "Hidrografia",
            opacity: 1.000000,
            visible: false,
            
          });
          const wmsSource = new TileWMS({
            url: 'https://ahocevar.com/geoserver/wms',
            params: {'LAYERS': 'ne:ne', 'TILED': true},
            serverType: 'geoserver',
            crossOrigin: 'anonymous'
          });

///////////////////fin declaracion de capas////////////////////////////////

        var view = new View({
            extent: [-7765583.071159, -5055260.408855, -5601262.345613, -3864750.244618], maxZoom: 28, minZoom: 1
            
        });
        const map = new Map({
            target: 'osm_map',
            layers: [
                new ol.layer.Group({
                    // A layer must have a title to appear in the layerswitcher
                    'title': 'Capas Base',
                    layers: [
                        googleSat,
                        OSM, 
                    ]
                }),
                new ol.layer.Group({
                    // A layer must have a title to appear in the layerswitcher
                    title: 'Capas Info.',
                    // Adding a 'fold' property set to either 'open' or 'close' makes the group layer
                    // collapsible
                    fold: 'open',
                    layers: [
                            ///////////////////////catastro////////////////////
                        new ol.layer.Group({
                            // A layer must have a title to appear in the layerswitcher
                            title: 'Catastro',
                            fold: 'open',                           
                            layers: [
                                parcelas,
                                zUsos,
                                municipalidades,
                                departamentos,
                               
                            ]
                        }),
                        ////////////////hidraulica///////////////////////
                        new ol.layer.Group({
                            // A layer must have a title to appear in the layerswitcher
                            title: 'Hidraulica',
                            fold: 'open',
                            layers: [
                                hidrografia,
                               
                            ]
                        })
                        ///////////////////////////////////////////////////////////
                    ]
                })
            ],
            view: view
            
        });
        map.getView().fit([-7765583.071159, -5055260.408855, -5601262.345613, -3864750.244618], map.getSize());
        console.log('aca va algo'); 
       // var zoomslider = new ZoomSlider();
       // map.addControl(zoomslider);
       // var sidebar = new ol.control.Sidebar({ element: 'sidebar', position: 'left' });

        //map.addControl(sidebar);
       // $("#titulo").html("Hello World");

        var sidebar = new ol.control.Sidebar({ element: 'sidebar', position: 'left' });
        map.addControl(sidebar);
        var toc = document.getElementById("layers");
        
        ol.control.LayerSwitcher.renderPanel(map, toc);
       // var viewResolution = view.getResolution();
        map.on('singleclick', function(evt) {



            var pixel = map.getEventPixel(evt.originalEvent);
            var pixelcoord = evt.coordinate;
            //console.log(pixelcoord);
            var viewResolution = /** @type {number} */ (view.getResolution());
           // console.log('sjsjsjsjs');
            map.forEachLayerAtPixel(pixel, function(feature, layer) {
              // console.log(feature);
               var tipo = feature.values_.type;
               if (tipo!='base'){
                  // feature.getSource()
                 // var url=fuente.getGetFeatureInfoUrl(  
                   // coordenada, viewResolution, view.getProjection(),{'INFO_FORMAT': 'application/json'}); 
                   var url = feature.getSource().getFeatureInfoUrl(
                    evt.coordinate, viewResolution, 'EPSG:3857',
                    {'INFO_FORMAT': 'application/json'});
                    console.log(url);
                    var originalURL = url;
                    var queryURL = "https://cors-anywhere.herokuapp.com/" + originalURL
/*
                    $.ajax({ //esta llamada se tendra que hacer tantas veces como capas existan, cambiando el cgi del url
                        jsonp: true,
                        jsonpCallback: 'getJson',
                        type: 'GET',
                        url: queryURL,
                        async: true,
                        dataType: 'json',
                        headers: {
                            "x-requested-with": "xhr" 
                          },
                        success: function(data) {
                           console.log(data);
                        
                        } //fin funcion
                    }); //fin ajax

*/

                    document.getElementById('info').innerHTML = url;
                    if (url) {
                        fetch(url)
                          .then(function (response) { return response.text(); })
                          .then(function (html) {
                            document.getElementById('info').innerHTML = url;
                            console.log('devolvio algo');
                          });
                    }
               }
                
            });
           /* map.forEachFeatureAtPixel(pixel, function(feature, layer) {
                console.log(feature);
            });*/
            //var layers = map.getLayers();
            //layers.array_.forEach(elemento => console.log(elemento.state_.visible));
            
          
           /* var url = departamentos.getSource().getFeatureInfoUrl(
              evt.coordinate, viewResolution, 'EPSG:3857',
              {'INFO_FORMAT': 'text/html'});*/
             // alert(url);
           // console.log(url);
            /*if (url) {
              fetch(url)
                .then(function (response) { return response.text(); })
                .then(function (html) {
                  document.getElementById('info').innerHTML = html;
                });
            }*/
          });

       // map.addControl(switcher);
    }
                               // <-- close the method
};                                   // <-- close the object



/*

var my_map = {                       // <-- add this line to declare the object
    display: 
    function() {
    var map = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Group({
                // A layer must have a title to appear in the layerswitcher
                'title': 'Base maps',
                layers: [
                    new ol.layer.Group({
                        // A layer must have a title to appear in the layerswitcher
                        title: 'Water color with labels',
                        // Setting the layers type to 'base' results
                        // in it having a radio button and only one
                        // base layer being visibile at a time
                        type: 'base',
                        // Setting combine to true causes sub-layers to be hidden
                        // in the layerswitcher, only the parent is shown
                        combine: true,
                        visible: false,
                        layers: [
                            new ol.layer.Tile({
                                source: new ol.source.Stamen({
                                    layer: 'watercolor'
                                })
                            }),
                            new ol.layer.Tile({
                                source: new ol.source.Stamen({
                                    layer: 'terrain-labels'
                                })
                            })
                        ]
                    }),
                    new ol.layer.Tile({
                        // A layer must have a title to appear in the layerswitcher
                        title: 'Water color',
                        // Again set this layer as a base layer
                        type: 'base',
                        visible: false,
                        source: new ol.source.Stamen({
                            layer: 'watercolor'
                        })
                    }),
                    new ol.layer.Tile({
                        // A layer must have a title to appear in the layerswitcher
                        title: 'OSM',
                        // Again set this layer as a base layer
                        type: 'base',
                        visible: true,
                        source: new ol.source.OSM()
                    })
                ]
            }),
            new ol.layer.Group({
                // A layer must have a title to appear in the layerswitcher
                title: 'Overlays',
                // Adding a 'fold' property set to either 'open' or 'close' makes the group layer
                // collapsible
                fold: 'open',
                layers: [
                    new ol.layer.Image({
                        // A layer must have a title to appear in the layerswitcher
                        title: 'Countries',
                        source: new ol.source.ImageArcGISRest({
                            ratio: 1,
                            params: {'LAYERS': 'show:0'},
                            url: "https://ons-inspire.esriuk.com/arcgis/rest/services/Administrative_Boundaries/Countries_December_2016_Boundaries/MapServer"
                        })
                    }),
                    new ol.layer.Group({
                        // A layer must have a title to appear in the layerswitcher
                        title: 'Census',
                        fold: 'open',
                        layers: [
                            new ol.layer.Image({
                                // A layer must have a title to appear in the layerswitcher
                                title: 'Districts',
                                source: new ol.source.ImageArcGISRest({
                                    ratio: 1,
                                    params: {'LAYERS': 'show:0'},
                                    url: "https://ons-inspire.esriuk.com/arcgis/rest/services/Census_Boundaries/Census_Merged_Local_Authority_Districts_December_2011_Boundaries/MapServer"
                                })
                            }),
                            new ol.layer.Image({
                                // A layer must have a title to appear in the layerswitcher
                                title: 'Wards',
                                visible: false,
                                source: new ol.source.ImageArcGISRest({
                                    ratio: 1,
                                    params: {'LAYERS': 'show:0'},
                                    url: "https://ons-inspire.esriuk.com/arcgis/rest/services/Census_Boundaries/Census_Merged_Wards_December_2011_Boundaries/MapServer"
                                })
                            })
                        ]
                    })
                ]
            })
        ],
        view: new ol.View({
            center: ol.proj.transform([-0.92, 52.96], 'EPSG:4326', 'EPSG:3857'),
            zoom: 6
        })
    });

    // Get out-of-the-map div element with the ID "layers" and renders layers to it.
    // NOTE: If the layers are changed outside of the layer switcher then you
    // will need to call ol.control.LayerSwitcher.renderPanel again to refesh
    // the layer tree. Style the tree via CSS.
  
    var sidebar = new ol.control.Sidebar({ element: 'sidebar', position: 'left' });
    var toc = document.getElementById("layers");
    ol.control.LayerSwitcher.renderPanel(map, toc);
    map.addControl(sidebar);

}};*/
export default my_map; 