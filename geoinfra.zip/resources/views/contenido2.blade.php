@extends('layouts.layMapa')

@section('content')

<h4>un titulo en otro contenido</h4>
<script>console.log('sjsjsjs');</script>
<div id="app">
    <div id="osm_map"></div>
</div>


<script type="text/javascript">
    window.my_map.display();
</script>
@endsection