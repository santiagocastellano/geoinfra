<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
        #osm_map {
            position: absolute;
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
<script src="<?php echo e(asset('js/app.js')); ?>"  ></script>
<h4>Titulo del layer de base</h4>

<main >
            <?php echo $__env->yieldContent('content'); ?>

        </main>
</body>
</html><?php /**PATH F:\programacion\geoinfra\resources\views/layouts/layMapa.blade.php ENDPATH**/ ?>