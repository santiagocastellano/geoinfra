

<?php $__env->startSection('content'); ?>

<h4>un titulo en otro contenido</h4>
<script>console.log('sjsjsjs');</script>
<div id="app">
    <div id="osm_map"></div>
</div>


<script type="text/javascript">
    window.my_map.display();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layMapa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\programacion\geoinfra\resources\views/contenido2.blade.php ENDPATH**/ ?>